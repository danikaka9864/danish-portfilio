export var row = document.querySelector('.row')
  , list = document.querySelector('.item-1')
  , list = document.querySelector('.item-2')
  , list = document.querySelector('.item-3')
  , clone = list.cloneNode(true)

